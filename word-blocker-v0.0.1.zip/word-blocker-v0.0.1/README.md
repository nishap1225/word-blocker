# word-blocker
Chrome extension to block passages which include certain words. 
